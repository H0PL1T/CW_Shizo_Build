### v1.0.1
- Color now applys in dive

### v1.0.0
- Release