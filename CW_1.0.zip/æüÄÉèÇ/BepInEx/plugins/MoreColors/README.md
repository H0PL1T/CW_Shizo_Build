# MoreColors
- Adds more face colors
- More soon

![ingame image](https://i.imgur.com/O2OLRxC.png)

More info can be found on the [modding discord](https://discord.com/channels/1224455971057958954/1224806452464455854)