# Volume Booster
Having trouble hearing other people because voice chat is too quiet? Just want to tweak the game volume beyond its limits? This is the mod for you! General, SFX, and Voice volume limits can be configured as high as you want (via Configuration Manager)
- Increases the max for the in-game volume settings to whatever limit you configure with Configuration Manager

## Requirements
- BepInEx v5.4.22
- BepInEx Configuration Manager