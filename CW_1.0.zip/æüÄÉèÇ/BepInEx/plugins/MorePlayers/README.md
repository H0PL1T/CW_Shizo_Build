# Virality

*A better multiplayer mod for Content Warning*

## Features
- Bigger lobby sizes (configurable limit)
- Late joining (configurable on/off)
- Right click Steam join (configurable on/off)

## Notes
- Required by all players to work properly!
- Supports all vanilla player features (i.e. showing up in video comments, hospital bills, etc...)
- Only 4 players need to sleep to progress the day

## Requirements
- BepInEx LTS (5.4.22)

## Credits
- Day (Little Llama) -- Bed patches, support, testing
- sovenance -- Mod name idea