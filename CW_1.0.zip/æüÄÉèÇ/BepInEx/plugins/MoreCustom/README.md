# More Customization!

"You want to customize your face further don't you?"

## Features
- 128 Character Limit For Face Customization
- Copy/Paste in Terminal
- Infinite Size Adjustment For Face

## Notes
- Required to be installed for all clients.
- Supports all vanilla player features, also supports Virality Mod.

## Requirements
- BepInEx LTS (5.4.22)

## Credits
- Day (Little Llama) -- Testing
- Plackard -- Testing